package com.example.itsdivyanshu;

import android.Manifest;
import android.app.DownloadManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.net.URLDecoder;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private long backPressedTime;
    private Toast backToast;
    private static final int PERMISSION_REQUEST_CODE = 101;
    private String currentUrl = "https://i-am-divyanshu.netlify.app/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);

        // Ask permission
        requestStoragePermission();

        // Setup WebView
        configureWebView();

        // Handle downloads
        setupDownloadListener();

        // Handle back button
        setupBackButtonHandler();

        // Check internet and load
        loadWebsite();
    }

    private void loadWebsite() {
        if (isNetworkAvailable()) {
            webView.loadUrl(currentUrl);
        } else {
            loadErrorPage();
        }
    }

    private void loadErrorPage() {
        webView.loadUrl("file:///android_asset/no_internet.html");
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        if (connectivityManager != null) {
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            return activeNetworkInfo != null && activeNetworkInfo.isConnected();
        }
        return false;
    }

    private void configureWebView() {
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setSupportZoom(true);
        webSettings.setBuiltInZoomControls(true);
        webSettings.setDisplayZoomControls(false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);

        // Set custom WebViewClient
        webView.setWebViewClient(new CustomWebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
    }

    // Custom WebViewClient to handle errors
    private class CustomWebViewClient extends WebViewClient {

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request,
                                    WebResourceError error) {
            super.onReceivedError(view, request, error);

            // Only handle main page errors, not resource errors
            if (request.isForMainFrame()) {
                loadErrorPage();
            }
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);

            // Handle custom reload URL from error page
            if (url.equals("reload://")) {
                view.stopLoading();
                loadWebsite();
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            String url = request.getUrl().toString();

            // Handle custom reload URL
            if (url.equals("reload://")) {
                loadWebsite();
                return true;
            }

            return false;
        }
    }

    private void setupBackButtonHandler() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack();
                } else {
                    if (backPressedTime + 2000 > System.currentTimeMillis()) {
                        if (backToast != null) backToast.cancel();
                        finish();
                    } else {
                        backToast = Toast.makeText(MainActivity.this,
                                "Press again to exit", Toast.LENGTH_SHORT);
                        backToast.show();
                    }
                    backPressedTime = System.currentTimeMillis();
                }
            }
        });
    }

    private void setupDownloadListener() {
        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent,
                                        String contentDisposition, String mimeType,
                                        long contentLength) {

                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    if (ContextCompat.checkSelfPermission(MainActivity.this,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE)
                            != PackageManager.PERMISSION_GRANTED) {
                        requestStoragePermission();
                        Toast.makeText(MainActivity.this,
                                "Please grant storage permission to download files",
                                Toast.LENGTH_LONG).show();
                        return;
                    }
                }

                // Convert GitHub blob to raw
                if (url.contains("github.com") && url.contains("/blob/")) {
                    url = url.replace("github.com", "raw.githubusercontent.com")
                            .replace("/blob/", "/");
                }

                downloadFile(url, userAgent, contentDisposition, mimeType);
            }
        });
    }

    private void downloadFile(String url, String userAgent,
                              String contentDisposition, String mimeType) {

        try {
            Toast.makeText(this, "Downloading File...", Toast.LENGTH_SHORT).show();

            String fileName = getFileName(url, contentDisposition, mimeType);

            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setMimeType(mimeType);
            String cookies = CookieManager.getInstance().getCookie(url);
            request.addRequestHeader("Cookie", cookies);
            request.addRequestHeader("User-Agent", userAgent);
            request.allowScanningByMediaScanner();
            request.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS, fileName);
            request.setTitle(fileName);
            request.setDescription("Downloading file...");

            DownloadManager downloadManager =
                    (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            if (downloadManager != null) {
                downloadManager.enqueue(request);
                Toast.makeText(this, "Download started: " + fileName,
                        Toast.LENGTH_LONG).show();
            }

        } catch (Exception e) {
            Toast.makeText(this, "Download failed: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private String getFileName(String url, String contentDisposition, String mimeType) {
        String fileName = null;

        try {
            // First try to extract from Content-Disposition header
            if (contentDisposition != null) {
                // Try filename* (RFC 5987) first - handles encoded filenames
                if (contentDisposition.contains("filename*=")) {
                    int startIndex = contentDisposition.indexOf("filename*=");
                    String filenamePart = contentDisposition.substring(startIndex);

                    // Extract the actual filename after encoding info (e.g., UTF-8''filename.pdf)
                    if (filenamePart.contains("''")) {
                        fileName = filenamePart.substring(filenamePart.indexOf("''") + 2);
                        // Remove anything after semicolon
                        if (fileName.contains(";")) {
                            fileName = fileName.substring(0, fileName.indexOf(";"));
                        }
                        fileName = URLDecoder.decode(fileName.trim(), "UTF-8");
                    }
                }

                // Fallback to filename= if filename* not found
                if (fileName == null && contentDisposition.contains("filename=")) {
                    int startIndex = contentDisposition.indexOf("filename=") + 9;
                    int endIndex = contentDisposition.indexOf(";", startIndex);
                    if (endIndex == -1) endIndex = contentDisposition.length();
                    fileName = contentDisposition.substring(startIndex, endIndex)
                            .replace("\"", "")
                            .replace("'", "")
                            .trim();

                    // Decode if it's URL encoded
                    if (fileName.contains("%")) {
                        fileName = URLDecoder.decode(fileName, "UTF-8");
                    }
                }
            }

            // If still no filename, try to extract from URL
            if (fileName == null || fileName.isEmpty()) {
                // Get the last segment of the URL path
                String urlPath = Uri.parse(url).getLastPathSegment();
                if (urlPath != null && !urlPath.isEmpty()) {
                    fileName = URLDecoder.decode(urlPath, "UTF-8");
                }
            }

            // Last resort: use URLUtil.guessFileName
            if (fileName == null || fileName.isEmpty()) {
                fileName = URLUtil.guessFileName(url, contentDisposition, mimeType);
            }

            // Ensure the filename has an extension
            if (!fileName.contains(".") && mimeType != null) {
                String extension = getExtensionFromMimeType(mimeType);
                if (extension != null) {
                    fileName += extension;
                }
            }

        } catch (Exception e) {
            // Fallback to timestamp-based filename with proper extension
            fileName = "download_" + System.currentTimeMillis();
            if (mimeType != null) {
                String extension = getExtensionFromMimeType(mimeType);
                if (extension != null) {
                    fileName += extension;
                }
            }
        }

        return fileName;
    }

    // Helper method to get file extension from MIME type
    private String getExtensionFromMimeType(String mimeType) {
        if (mimeType == null) return null;

        switch (mimeType.toLowerCase()) {
            // Images
            case "image/jpeg":
            case "image/jpg":
                return ".jpg";
            case "image/png":
                return ".png";
            case "image/gif":
                return ".gif";
            case "image/webp":
                return ".webp";
            case "image/svg+xml":
                return ".svg";
            case "image/bmp":
                return ".bmp";

            // Videos
            case "video/mp4":
                return ".mp4";
            case "video/mpeg":
                return ".mpeg";
            case "video/quicktime":
                return ".mov";
            case "video/x-msvideo":
                return ".avi";
            case "video/webm":
                return ".webm";
            case "video/3gpp":
                return ".3gp";
            case "video/x-matroska":
                return ".mkv";

            // Audio
            case "audio/mpeg":
            case "audio/mp3":
                return ".mp3";
            case "audio/wav":
                return ".wav";
            case "audio/ogg":
                return ".ogg";
            case "audio/webm":
                return ".weba";
            case "audio/aac":
                return ".aac";
            case "audio/flac":
                return ".flac";
            case "audio/x-m4a":
                return ".m4a";

            // Documents
            case "application/pdf":
                return ".pdf";
            case "application/msword":
                return ".doc";
            case "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
                return ".docx";
            case "application/vnd.ms-excel":
                return ".xls";
            case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
                return ".xlsx";
            case "application/vnd.ms-powerpoint":
                return ".ppt";
            case "application/vnd.openxmlformats-officedocument.presentationml.presentation":
                return ".pptx";
            case "text/plain":
                return ".txt";
            case "text/html":
                return ".html";
            case "text/css":
                return ".css";
            case "text/javascript":
            case "application/javascript":
                return ".js";
            case "application/json":
                return ".json";
            case "application/xml":
            case "text/xml":
                return ".xml";
            case "text/csv":
                return ".csv";
            case "application/rtf":
                return ".rtf";

            // Archives
            case "application/zip":
                return ".zip";
            case "application/x-rar-compressed":
            case "application/vnd.rar":
                return ".rar";
            case "application/x-7z-compressed":
                return ".7z";
            case "application/x-tar":
                return ".tar";
            case "application/gzip":
            case "application/x-gzip":
                return ".gz";

            // APK
            case "application/vnd.android.package-archive":
                return ".apk";

            // Other common formats
            case "application/octet-stream":
                return ".bin";

            default:
                // Try to extract extension from MIME type
                if (mimeType.contains("/")) {
                    String subtype = mimeType.substring(mimeType.indexOf("/") + 1);
                    // Remove any parameters after semicolon
                    if (subtype.contains(";")) {
                        subtype = subtype.substring(0, subtype.indexOf(";"));
                    }
                    return "." + subtype.trim();
                }
                return null;
        }
    }

    // Works for Android 6 through Android 16
    private void requestStoragePermission() {
        int sdk = Build.VERSION.SDK_INT;

        if (sdk >= 35) { // Android 16+ future-proof
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES)
                    != PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO)
                            != PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO)
                            != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this,
                        new String[]{
                                Manifest.permission.READ_MEDIA_IMAGES,
                                Manifest.permission.READ_MEDIA_VIDEO,
                                Manifest.permission.READ_MEDIA_AUDIO
                        }, PERMISSION_REQUEST_CODE);
            }

        } else if (sdk >= Build.VERSION_CODES.TIRAMISU) { // Android 13–15
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES)
                    != PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO)
                            != PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO)
                            != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this,
                        new String[]{
                                Manifest.permission.READ_MEDIA_IMAGES,
                                Manifest.permission.READ_MEDIA_VIDEO,
                                Manifest.permission.READ_MEDIA_AUDIO
                        }, PERMISSION_REQUEST_CODE);
            }

        } else if (sdk >= Build.VERSION_CODES.M) { // Android 6–12
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                            != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this,
                        new String[]{
                                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                Manifest.permission.READ_EXTERNAL_STORAGE
                        }, PERMISSION_REQUEST_CODE);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission is required to download files",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}

/*
 * Add these permissions to your AndroidManifest.xml:
 *
 * <uses-permission android:name="android.permission.INTERNET" />
 * <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
 *
 * <!-- Android 6–12 -->
 * <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"
 *     android:maxSdkVersion="32" />
 * <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"
 *     android:maxSdkVersion="32" />
 *
 * <!-- Android 13–16 -->
 * <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
 * <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />
 * <uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />
 */